<?php
/**
 * Plugin Name: HomePage Canonical
 * Description: Force homepage canonical and hreflang for VI-VN
 * Version: 2.0
 * Author: Ed 7
 */

if (!defined('ABSPATH')) exit;


function fvvc_base_url() {
    $scheme = is_ssl() ? 'https://' : 'http://';
    return $scheme . $_SERVER['HTTP_HOST'];
}


function fvvc_add_rewrite_rule() {
    add_rewrite_rule(
        '^vi-vn/?$',
        'index.php',
        'top'
    );
}
add_action('init', 'fvvc_add_rewrite_rule');


add_filter('redirect_canonical', function ($redirect_url) {

    if (is_front_page() || is_home()) {
        return false;
    }

    return $redirect_url;
}, 0);


add_filter('rel_canonical', function ($canonical) {

    if (is_front_page() || is_home()) {
        return fvvc_base_url() . '/vi-vn/';
    }

    return $canonical;

}, 9999);

add_filter('get_canonical_url', function ($canonical) {

    if (is_front_page() || is_home()) {
        return fvvc_base_url() . '/vi-vn/';
    }

    return $canonical;

}, 9999);


/** RankMath */
add_filter('rank_math/frontend/canonical', function ($canonical) {

    if (is_front_page() || is_home()) {
        return fvvc_base_url() . '/vi-vn/';
    }

    return $canonical;

}, 9999);


/** Yoast SEO */
add_filter('wpseo_canonical', function ($canonical) {

    if (is_front_page() || is_home()) {
        return fvvc_base_url() . '/vi-vn/';
    }

    return $canonical;

}, 9999);


add_action('template_redirect', function () {

    if (is_front_page() || is_home()) {
        remove_action('template_redirect', 'redirect_canonical');
    }

}, 0);


add_action('wp_head', function () {

    if (is_front_page() || is_home()) {

        $url = fvvc_base_url() . '/vi-vn/';

        echo '<link rel="alternate" hreflang="vi-VN" href="' . esc_url($url) . '" />' . "\n";
        echo '<link rel="alternate" hreflang="vi" href="' . esc_url($url) . '" />' . "\n";
        echo '<link rel="alternate" hreflang="x-default" href="' . esc_url($url) . '" />' . "\n";
        echo '<link rel="shortlink" href="' . fvvc_base_url() . '" />' . "\n";
    }

}, 1);

register_activation_hook(__FILE__, function () {

    fvvc_add_rewrite_rule();
    flush_rewrite_rules();
});


register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

