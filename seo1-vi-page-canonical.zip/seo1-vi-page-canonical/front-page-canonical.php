<?php
/**
 * Plugin Name: HomePage Canonical
 * Description: Giữ trang chủ ở / nhưng vẫn tạo URL locale /vi-vn/ hoạt động thật, đồng thời xuất canonical + hreflang trỏ về /vi-vn/.
 * Version: 5.0.0
 * Author: Ed 7
 */

if (!defined('ABSPATH')) {
    exit;
}

final class FVVC_Home_Canonical {
    const VERSION = '2.0';
    const QUERY_VAR = 'fvvc_locale_home';
    const DEFAULT_SLUG = 'vi-vn';

    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        add_action('init', array($this, 'add_rewrite_rule'));
        add_filter('query_vars', array($this, 'register_query_var'));

        add_filter('redirect_canonical', array($this, 'disable_redirect_canonical_for_locale'), 10, 2);
        add_action('wp', array($this, 'mark_locale_request_as_front_page'), 1);

        add_action('wp_head', array($this, 'remove_default_canonical'), 0);
        add_action('wp_head', array($this, 'output_head_tags'), 1);

        add_filter('pre_get_shortlink', array($this, 'filter_shortlink'), 10, 4);

        add_filter('wpseo_canonical', array($this, 'filter_canonical'));
        add_filter('rank_math/frontend/canonical', array($this, 'filter_canonical'));
        add_filter('aioseo_canonical_url', array($this, 'filter_canonical'));
        add_filter('get_canonical_url', array($this, 'filter_canonical'));
        add_filter('wpseo_frontend_presenters', array($this, 'filter_wpseo_presenters'), 99);
        add_filter('body_class', array($this, 'filter_body_class'), 20, 2);
    }

    public function activate() {
        $this->add_rewrite_rule();
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }

    public function add_rewrite_rule() {
        $slug = preg_quote($this->get_locale_slug(), '/');
        $front_page_id = (int) get_option('page_on_front');

        if ($front_page_id > 0) {
            add_rewrite_rule(
                '^' . $slug . '/?$',
                'index.php?page_id=' . $front_page_id . '&' . self::QUERY_VAR . '=1',
                'top'
            );
            return;
        }

        add_rewrite_rule(
            '^' . $slug . '/?$',
            'index.php?' . self::QUERY_VAR . '=1',
            'top'
        );
    }

    public function register_query_var($vars) {
        $vars[] = self::QUERY_VAR;
        return $vars;
    }

    public function disable_redirect_canonical_for_locale($redirect_url, $requested_url) {
        if ($this->is_locale_home_request()) {
            return false;
        }
        return $redirect_url;
    }

    public function mark_locale_request_as_front_page() {
        if (!$this->is_locale_home_request()) {
            return;
        }

        global $wp_query;

        if (!($wp_query instanceof WP_Query)) {
            return;
        }

        $wp_query->is_front_page = true;
        $wp_query->is_home = false;

        $front_page_id = (int) get_option('page_on_front');
        if ($front_page_id > 0) {
            $wp_query->is_page = true;
            $wp_query->is_singular = true;
        }
    }

    public function remove_default_canonical() {
        if ($this->is_home_context()) {
            remove_action('wp_head', 'rel_canonical');
        }
    }

    public function output_head_tags() {
        if (!$this->is_home_context()) {
            return;
        }

        $shortlink = esc_url(home_url('/'));
        $canonical = esc_url($this->get_locale_url());

        echo "\n" . '<link rel="shortlink" href="' . $shortlink . '" />' . "\n";
        echo '<link rel="canonical" href="' . $canonical . '" />' . "\n";
        echo '<link rel="alternate" hreflang="vi-VN" href="' . $canonical . '" />' . "\n";
        echo '<link rel="alternate" hreflang="vi" href="' . $canonical . '" />' . "\n";
        echo '<link rel="alternate" hreflang="x-default" href="' . $canonical . '" />' . "\n";
    }

    public function filter_shortlink($override_shortlink, $id, $context, $allow_slugs) {
        if ($this->is_home_context()) {
            return home_url('/');
        }
        return $override_shortlink;
    }

    public function filter_canonical($canonical) {
        if ($this->is_home_context()) {
            return $this->get_locale_url();
        }
        return $canonical;
    }

    public function filter_wpseo_presenters($presenters) {
        if (!$this->is_home_context() || !is_array($presenters)) {
            return $presenters;
        }

        foreach ($presenters as $index => $presenter) {
            if (is_object($presenter) && strpos(get_class($presenter), 'Canonical') !== false) {
                unset($presenters[$index]);
            }
        }

        return $presenters;
    }

    public function filter_body_class($classes, $css_class) {
        if (!$this->is_locale_home_request()) {
            return $classes;
        }

        $need = array('home', 'page-template-default', 'page');
        $front_page_id = (int) get_option('page_on_front');
        if ($front_page_id > 0) {
            $need[] = 'page-id-' . $front_page_id;
        }

        foreach ($need as $class) {
            if (!in_array($class, $classes, true)) {
                $classes[] = $class;
            }
        }

        return array_values(array_unique($classes));
    }

    private function is_home_context() {
        return is_front_page() || $this->is_locale_home_request();
    }

    private function is_locale_home_request() {
        return (bool) get_query_var(self::QUERY_VAR);
    }

    private function get_locale_slug() {
        return self::DEFAULT_SLUG;
    }

    private function get_locale_url() {
        return home_url('/' . $this->get_locale_slug() . '/');
    }
}

new FVVC_Home_Canonical();
